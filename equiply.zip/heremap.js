function moveMapToBerlin(map) {
    map.setCenter({lat:52.5159, lng:13.3777});
    map.setZoom(10);
  } 
    //  var AUTOCOMPLETION_URL = 'https://uz8y831zf8.execute-api.eu-central-1.amazonaws.com/Stage/geocodesuggest/';
    //  var GEOCODER_URL = 'https://geocoder.api.here.com/6.2/geocode.json';
      var ROUTING_URL = 'https://route.api.here.com/routing/7.2/calculateroute.json';

      var platform = new H.service.Platform({
          apikey: `-XM4F_qOt1W1bjRkuvcdTLpRXnpJGBbAb2Kr25mYwGc`
      });
      var defaultLayers = platform.createDefaultLayers();

      //Step 2: initialize a map - this map is centered over Europe
      var map = new H.Map(document.getElementById('map'),
          defaultLayers.vector.normal.map, {
          center: { lat: 50, lng: 5 },
          zoom: 4,
          pixelRatio: window.devicePixelRatio || 1
      });
      // add a resize listener to make sure that the map occupies the whole container
      window.addEventListener('resize', () => map.getViewPort().resize());
      //Step 3: make the map interactive
      // MapEvents enables the event system
      // Behavior implements default interactions for pan/zoom (also on mobile touch environments)
      var behavior = new H.mapevents.Behavior(new H.mapevents.MapEvents(map));
       
       var ui = H.ui.UI.createDefault(map, defaultLayers);

        window.onload = function () {
        moveMapToBerlin(map);
        //getDeafultLocation();
      } 
      var input1 = document.getElementById("from");
       const autosuggest2 = (e) => {
          if(event.metaKey) {
            return
          } 
          let searchString = e.value
          if (searchString != "") {
            fetch(`https://autosuggest.search.hereapi.com/v1/autosuggest?apiKey=${'-XM4F_qOt1W1bjRkuvcdTLpRXnpJGBbAb2Kr25mYwGc'}&at=33.738045,73.084488&limit=5&resultType=city&q=${searchString}&lang=en-US`)
            .then(res => res.json())
            .then((json) => {
              if (json.length != 0) {
                document.getElementById("list").innerHTML = ``;
                let dropData = json.items.map((item) => {
                  if ((item.position != undefined) & (item.position != ""))
                    document.getElementById("list").innerHTML += `<li onClick="addMarkerToMap(${item.position.lat},${item.position.lng},'${item.title}')">${item.title}</li>`;
                  });
              }
            });
          }
        };
       const autosuggest = (e) => {
          if(event.metaKey) {
            return
          } 
          let searchString = e.value
          if (searchString != "") {
            fetch(`https://autosuggest.search.hereapi.com/v1/autosuggest?apiKey=${'-XM4F_qOt1W1bjRkuvcdTLpRXnpJGBbAb2Kr25mYwGc'}&at=33.738045,73.084488&limit=5&resultType=city&q=${searchString}&lang=en-US`)
            .then(res => res.json())
            .then((json) => {
              if (json.length != 0) {
                document.getElementById("list1").innerHTML = ``;
                let dropData = json.items.map((item) => {
                  if ((item.position != undefined) & (item.position != ""))
                    document.getElementById("list1").innerHTML += `<li onClick="addMarkerToMap1(${item.position.lat} ,${item.position.lng},'${item.title}')">${item.title}</li>`;
                  });
              }
            });
          }
        };
              // to get deafult location
          // function getDeafultLocation(){
          //     var lat=52.5159;
          //     var lng=13.3777;
          //     var title = "Berlin, Germany";
          //     addMarkerToMap(lat, lng, title);
          // }
        
          var routeLocations = [];
          function addLocationToRoute(){
            var loc = response.Response.View[0].Result[0].Location.DisplayPosition;
            routeLocations = routeLocations.concat([loc]);

            if (routeLocations.length < 2)
                return;

            var params = '?mode=fastest;car;traffic:disabled&routeAttributes=shape' +
                '&apiKey=' + '-XM4F_qOt1W1bjRkuvcdTLpRXnpJGBbAb2Kr25mYwGc';

            routeLocations.forEach(function (v,i)
            {
                params += `&waypoint${i}=geo!${v.Latitude},${v.Longitude}`;
            });

            $.ajax({
                url: ROUTING_URL + params,
                type: 'get',
                dataType: 'json',
                success: onRoutingSuccess,
                error: onRoutingFailed
            });
          }
          const addMarkerToMap = (lat, lng, title) => {
              // map.removeObjects(map.getObjects())
              document.getElementById("from").value =  title;
              var selectedLocationMarker = new H.map.Marker({ lat, lng });
              map.addObject(selectedLocationMarker);
             
             document.getElementById("fromId").value =  lat + ',' + lng;
             var x =document.getElementById("fromId").value;
            console.log(x);
              document.getElementById("list").innerHTML = ``;
              map.setCenter({ lat, lng }, true); 
          };   
          const addMarkerToMap1 = (lat, lng, title) => {
              // map.removeObjects(map.getObjects())
              document.getElementById("search").value = title;
              var selectedLocationMarker = new H.map.Marker({ lat, lng });
              map.addObject(selectedLocationMarker);
              document.getElementById("list1").innerHTML = ``;

              map.setCenter({ lat, lng }, true); 
              var to = 'geo!' + lat + ',' + lng;
              calcRoute(to);
              map.setZoom(12);
          };  

               function calcRoute(toHere){
            const request = {
           mode: 'fastest;car',
           waypoint0: document.getElementById("fromId").value,
           waypoint1: toHere,
           representation: 'display'
        };
        //Initialize routing service
        const router = platform.getRoutingService();
        router.calculateRoute(request, response => {
           //Parse the route's shape
           const shape = response.response.route[0].shape.map(x => x.split(','));
           const linestring = new H.geo.LineString();
           shape.forEach(s => linestring.pushLatLngAlt(s[0], s[1]));
           //Create a polyline with the shape
           const routeLine = new H.map.Polyline(linestring, {
            //   style: { strokeColor: 'blue', lineWidth: 3 }
            style: {
                lineWidth: 5,
                strokeColor: 'rgba(0, 128, 255, 0.7)',
                lineTailCap: 'arrow-tail',
                lineHeadCap: 'arrow-head'
              }
           });
           let routeArrows = new window.H.map.Polyline(linestring, {
            style: {
              lineWidth: 10,
              fillColor: 'white',
              strokeColor: 'rgba(255, 255, 255, 1)',
              lineDash: [0, 2],
              lineTailCap: 'arrow-tail',
              lineHeadCap: 'arrow-head' }
            }
          )
           //Add route to map
           map.addObject(routeLine,routeArrows);
           //Zoom to bounds of the route shape
           map.getViewModel().setLookAtData({ bounds: routeLine.getBoundingBox() });
        });

        }